package ProjectManagement;

interface UserReport_ {

   default String user()    { return null; }

   default int consumed() { return 0; }

}

