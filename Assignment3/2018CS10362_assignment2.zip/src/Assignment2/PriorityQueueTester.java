// Use this driver for the testing the correctness of your priority queue implementation
// You can change the add, remove sequence to test for various scenarios.
public class PriorityQueueTester {
    public static void main(String[] args) {
	PriorityQueue<Integer> pq = new PriorityQueue<Integer>(5);
	
	int i = 0;
	while(!pq.isFull()) {
		pq.enqueue(new Node(i,i));
		System.out.println("Added "+i);
		i += 1;
	}
	
	while(!pq.isEmpty()) {
		System.out.println("removed "+ pq.dequeue().value);
	}
	
	//pq.display();
	
    }
}