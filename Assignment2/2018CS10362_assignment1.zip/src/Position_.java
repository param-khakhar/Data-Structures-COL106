public interface Position_<T> {// Supports any class T
	   public T value();          // Return value at position
	   public Position_<T> after();// Returns the position after this position in its list
	}
